#ifndef __IO_RAM_H
#define __IO_RAM_H

#define IORAM_BASE_PHYS 0xff000000UL
#define IORAM_LEN       0x10000UL

#endif
