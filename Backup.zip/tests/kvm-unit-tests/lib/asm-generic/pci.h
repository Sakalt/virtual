#ifndef _ASM_GENERIC_PCI_H_
#define _ASM_GENERIC_PCI_H_
#error need architecture specific asm/pci.h
#endif
