# About

The tests in this folder are not comprehensive by any means at the
moment.

# Automated Testing

- Run `make nasmtests` in the root of the project
